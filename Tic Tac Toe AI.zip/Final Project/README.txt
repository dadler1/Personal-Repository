main.py

This file requires no input parameters or additional files, and can simply be run with "python main.py"

When the program is run, an interface will be provided that will give the user the option to engage in
one of two modes.

Mode 1:

The player can play against the minimaxing algorithm themselves, being given the ability to make whatever 
moves they'd like against the algorithm by selecting one of the tiles to insert their symbol into:
[A1, A2, A3, B1, B2, B3, C1, C2, C3]


Mode 2:

The computer will play against itself, with one side making use of the minimaxing algorithm while the
other side makes use of total randomness. This process will occur a number of times equal to the value
of the NUM_ITERATIONS global constant. At the end of the iterations, information will be displayed
regarding the winrates, lossrates, and tie rates of the minimax player against the random player.

