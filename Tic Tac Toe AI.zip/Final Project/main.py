import sys
import copy
import random
import time

NUM_ITERATIONS = 50  # Represents how many games you would like to simulate during computer vs. computer

"""
Function:       to_symbol
Parameters:     turn    -> integer of value -1 or 1 or 0 occupancy of a cell
Returns:        symbol -> X or O if occupied by a player, - if the  cell is empty
Description:    Helper function in order to assist with printing of board
"""


def to_symbol(turn):
    return "X" if turn == -1 else "O" if turn == 1 else "-"


"""
Function:       other turn
Parameters:     turn    -> integer of value -1 or 1 representing whose turn it is
Returns:        other   -> returns opposite of current turn value (-1, 1)
Description:    Helper function in order to assist with turn operations
"""


def other_turn(turn):
    return 1 if turn == -1 else -1


"""
Function:       get_next_child
Parameters:     cur_state   -> BoardState you would like to get the child of
                cell        -> cell representation of move made by either player or computer
Returns:        child
Description:    Gets the appropriate child of the current board state based on the move made
"""


def get_next_child(cur_state, cell):
    board = copy.deepcopy(cur_state.board)
    row, col = cell_to_indexes(cell)
    board[row][col] = other_turn(cur_state.turn)
    for child in cur_state.children:
        if child.board == board:
            return child


"""
Function:       cell_to_indexes
Parameters:     cell    -> string indicator of where symbol should be placed
Returns:        row     -> represents row associated with cell value
                col     -> represents column associated with cell value
Description:    Helper function that gets rows and columns based on input strings
"""


def cell_to_indexes(cell):
    rows = {"A": 0, "B": 1, "C": 2}
    return rows[cell[0]], int(cell[1]) - 1


"""
Class:          GameStats
Parents:        None
Data Members:   player_wins     -> represents the number of wins that the player or random computer has accumulated
                ties            -> represents the number of ties that have occured
                computer_wins   -> represents the number of wins that the minimax computer has accumulated

Description:    Stores data about the number of wins each party has successfully achieved
"""


class GameStats:

    """
    Function:       default constructor
    Parameters:     None
    Returns:        None
    Description:    Initializes the stats displayed at the end of each game iteration
    """
    def __init__(self):
        self.player_wins = 0
        self.ties = 0
        self.computer_wins = 0

    """
    Function:       print_stats
    Parameters:     None
    Returns:        None
    Description:    prints the number of different outcomes as a percentage of the total games played
    """
    def print_stats(self):
        total = self.player_wins + self.ties + self.computer_wins
        print("Random Wins:\t" + str(round(self.player_wins/total*100, 2)) + "%")
        print("Ties:\t\t\t" + str(round(self.ties/total*100, 2)) + "%")
        print("Minimax Wins:\t" + str(round(self.computer_wins/total*100, 2)) + "%")


"""
Class:          BoardState
Parents:        None
Data Members:   depth       -> Represents the depth of the BoardState within the tree data structure
                turn        -> Int of value 1 or -1 that dictates whether it is the computer's or player's turn
                board       -> A 2D array representing the current board
                score       -> Value of -1, 0, or 1 representing whether the board is considered neutral, a player win,
                               or a computer win. It is then transformed into the minimax value of the current node's
                               children.
                children    -> A list of BoardState objects that are considered child nodes of the current BoardState
                empty_cells -> A list of cells that are available for input for the BoardState
                
Description:    Holds information related to the current state of the board in such a way that it becomes
                usable within a tree data structure for minimax
"""


class BoardState:

    """
    Function:       constructor
    Parameters:     board   -> A 2D array representing the current board
                    turn    -> Int of value 1 or -1 that dictates whether it is the computer's or player's turn
                    depth   -> Represents the depth of the BoardState within the tree data structure
    Returns:        None
    Description:    Recursively assigns the tree of BoardStates based on which player goes first
    """
    def __init__(self, board=None, turn=1, depth=0):
        self.depth = depth
        self.turn = turn
        if board is None:
            self.board = [[0, 0, 0],
                          [0, 0, 0],
                          [0, 0, 0]]
        else:
            self.board = board
        self.score = self.obtain_score()
        self.children = self.generate_children()
        self.empty_cells = self.get_valid_cells()
        child_scores = []
        if self.children is not None and turn == -1:
            for child in self.children:
                child_scores.append(child.score)
            self.score = max(child_scores)
        elif self.children is not None and turn == 1:
            for child in self.children:
                child_scores.append(child.score)
            self.score = min(child_scores)

    """
    Function:       get_valid_cells
    Parameters:     None
    Returns:        valid_cells -> list of cells that either the player or computer can mark
    Description:    Analyzes the current board to determine which cells can be modified
    """
    def get_valid_cells(self):
        valid_cells = ["C3", "C2", "C1", "B3", "B2", "B1", "A3", "A2", "A1"]
        index = 8
        for row in range(len(self.board)):
            for col in range(len(self.board[row])):
                if self.board[row][col] != 0:
                    valid_cells.pop(index)
                index -= 1
        return list(reversed(valid_cells))

    def get_children(self):
        return self.children

    """
    Function:       print_board
    Parameters:     None
    Returns:        None
    Description:    Prints the current state of the board
    """
    def print_board(self):
        rows = ["A", "B", "C"]
        print(" \t1\t2\t3")
        for row in range(len(self.board)):
            print(rows[row], end="\t")
            for col in range(len(self.board[row])):
                print(to_symbol(self.board[row][col]), end="\t")
            print()

    """
    Function:       obtain_score
    Parameters:     None
    Returns:        score -> Returns -1 if board is a computer win, 0 if no win, 1 if player win
    Description:    Analyzes the state of the board and assigns it a score
    """
    def obtain_score(self):
        scores = []

        # Rows
        for i in range(len(self.board)):
            cur_score = 0
            for j in range(len(self.board[i])):
                cur_score += self.board[i][j]
            scores.append(cur_score)

        # Columns
        for i in range(len(self.board)):
            cur_score = 0
            for j in range(len(self.board[i])):
                cur_score += self.board[j][i]
            scores.append(cur_score)

        # Diagonals
        scores.append(sum([self.board[0][0], self.board[1][1], self.board[2][2]]))
        scores.append(sum([self.board[0][2], self.board[1][1], self.board[2][0]]))

        return 1 if 3 in scores else -1 if -3 in scores else 0

    """
    Function:       generate_children
    Parameters:     None
    Returns:        children -> a list of child nodes based on the turn and current state of the board
    Description:    Helper function used to generate a list of child nodes
    """
    def generate_children(self):
        children = []
        if self.score != 0:
            return None
        symbol = other_turn(self.turn)
        for row in range(len(self.board)):
            for col in range(len(self.board[row])):
                if self.board[row][col] == 0:
                    cur_board = copy.deepcopy(self.board)
                    cur_board[row][col] = symbol
                    children.append(BoardState(cur_board, symbol, self.depth+1))
        return None if not children else children

    """
    Function:       get_fittest_child
    Parameters:     None
    Returns:        child   -> represents the child node that is most qualified to be chosen by minimax
    Description:    Function used by computer in order to determine which branch to follow on the tree
    """
    def get_fittest_child(self):
        if len(self.children) == 0:
            return None
        max_i = -1
        for child_index in range(len(self.children)-1):
            if self.children[child_index].score > self.children[max_i].score:
                max_i = child_index
        return self.children[max_i]

    """
    Function:       is_full
    Parameters:     None
    Returns:        full    -> boolean that represents whether the board is filled
    Description:    function that determines whether the board is completely filled for the sake of win condition
    """
    def is_full(self):
        empty_count = 0
        for row in range(len(self.board)):
            for col in range(len(self.board[row])):
                if self.board[row][col] == 0:
                    empty_count += 1
        return empty_count == 0


def main():
    board = BoardState(board=None, turn=2 * random.randint(0, 1) - 1)
    stats = GameStats()
    index = 0
    iterations = sys.maxsize
    print("Please select the mode you would like to run (1/2) :")
    print("1. Player vs. Computer")
    print("2. Computer vs. Computer (Random vs. AI)")
    print("*. Exit")
    mode = int(input())
    if mode not in [1, 2]:
        sys.exit(0)
    if mode == 2:
        global NUM_ITERATIONS
        iterations = NUM_ITERATIONS
    while index < iterations:
        cur_board = board
        while True:
            # Turn Logic
            if mode == 1:
                cur_board.print_board()
                print(cur_board.empty_cells)
                print("Player's Turn:" if cur_board.turn == 1 else "Computer's Turn:")
            if cur_board.turn == 1:
                if mode == 1:
                    while True:
                        cell = input("Please enter a valid cell you would like to select: ").upper()
                        if cell in cur_board.empty_cells:
                            break
                    cur_board = get_next_child(cur_board, cell)
                else:
                    cur_board = get_next_child(cur_board,
                                               cur_board.empty_cells[random.randint(0, len(cur_board.empty_cells)-1)])
            else:
                cur_board = cur_board.get_fittest_child()

            # Win Condition Logic
            board_score = cur_board.obtain_score()
            if board_score != 0:
                cur_board.print_board()
                if mode == 1:
                    print("Player wins!" if board_score == -1 else "Computer Wins!")
                else:
                    if board_score == -1:
                        stats.player_wins += 1
                    else:
                        stats.computer_wins += 1
                break
            elif cur_board.is_full():
                stats.ties += 1
                break
        if mode == 1:
            repeat = input("would you like to play again? (1/2)\n1. Yes\n2. No")
            if int(repeat) != 1:
                break
        index += 1
    stats.print_stats()


if __name__ == '__main__':
    main()

