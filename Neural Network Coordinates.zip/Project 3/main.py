import sys
import random
import copy

""" ========= GLOBAL CONSTANTS =========="""
INITIAL_LEARNING_RATE = 0.2
NUM_EPOCHS = 200
THRESHOLD = 0.5

COORDINATES = ["Latitude", "Longitude"]
CONTINENTS = ["Africa", "America", "Antarctica", "Asia", "Australia", "Europe", "Arctic", "Atlantic", "Indian",
              "Pacific"]


class Neuron:
    def __init__(self, name):
        self.name = name
        self.true_positives = 0
        self.true_negatives = 0
        self.false_positives = 0
        self.false_negatives = 0

    def print_neuron(self):
        total = self.true_positives + self.true_negatives + self.false_positives + self.false_negatives
        print("Neuron:\t" + str(self.name))
        print("Correct:\t" + str(round(100*(self.true_positives + self.true_negatives)/total, 2)) + "%")
        print("True Positive:\t" + str(round(100 * (self.true_positives/total), 2)) + "%")
        print("True Negative:\t" + str(round(100 * (self.true_negatives/total), 2)) + "%")
        print("False Positive:\t" + str(round(100 * (self.false_positives/total), 2)) + "%")
        print("False Negative:\t" + str(round(100 * (self.false_negatives/total), 2)) + "%\n\n")


class Data:
    def __init__(self, lat, long, continent):
        self.latitude = lat
        self.longitude = long
        self.continent = continent

    def __str__(self):
        return str(self.latitude) + ", " + str(self.longitude) + ", " + self.continent


class Perceptron:
    def __init__(self):
        self.map = {}
        weight_index = 0
        global CONTINENTS, COORDINATES
        for coord in COORDINATES:
            input_map = {}
            for cont in CONTINENTS:
                cur_weight = random.randint(0, 1)
                input_map[cont] = cur_weight
                weight_index += 1
            self.map[coord] = input_map

    def update_weights(self, data_point):
        global THRESHOLD, INITIAL_LEARNING_RATE, CONTINENTS
        for cont in CONTINENTS:
            lat_weight = self.map["Latitude"][cont]
            long_weight = self.map["Longitude"][cont]
            output = int((data_point.latitude * lat_weight + data_point.longitude * long_weight) > THRESHOLD)
            correct = int(cont == data_point.continent)
            self.map["Latitude"][cont] = lat_weight + INITIAL_LEARNING_RATE * (correct - output) * data_point.latitude
            self.map["Longitude"][cont] = long_weight + INITIAL_LEARNING_RATE * (correct - output) * data_point.longitude

    def get_weights(self):
        weights = ""
        global CONTINENTS, COORDINATES
        for coord in COORDINATES:
            for cont in CONTINENTS:
                weights += (str(self.map[coord][cont]) + "\t")
        weights = weights[0:len(weights)-1]
        return weights

    def store_weights(self, filename):
        weights = self.get_weights()
        file = open(filename, "w")
        file.write(weights)
        file.close()

    def load_weights(self, filename):
        file = open(filename, "r")
        line = file.readline().split("\t")
        for i in range(len(line)):
            line[i] = float(line[i])
        file.close()
        self.map = {}
        weight_index = 0
        global CONTINENTS, COORDINATES
        for coord in COORDINATES:
            input_map = {}
            for cont in CONTINENTS:
                cur_weight = line[weight_index]
                input_map[cont] = cur_weight
                weight_index += 1
            self.map[coord] = input_map

    def print_weights(self):
        weights = ""
        global CONTINENTS, COORDINATES
        for coord in COORDINATES:
            print(coord + "\n")
            for cont in CONTINENTS:
                weights += cont + ": " + (str(self.map[coord][cont]) + "\t")
        print(weights)

    def get_guesses(self, data_point):
        global CONTINENTS, THRESHOLD
        guesses = {}
        for cont in CONTINENTS:
            lat_weight = self.map["Latitude"][cont]
            long_weight = self.map["Longitude"][cont]
            guess_output = int((data_point.latitude * lat_weight + data_point.longitude * long_weight) > THRESHOLD)
            guesses[cont] = guess_output
        return guesses


def read_in_file_data(datafile):
    data = []
    file = open(datafile, "r")
    for line in file:
        cur_line = line.strip("\n").split("\t")
        cur_data = Data((float(cur_line[0]) + 90)/180, (float(cur_line[1]) + 180)/360, cur_line[2])
        data.append(cur_data)

    file.close()
    return data


def main():
    training_data = read_in_file_data("nnTrainData.txt")
    testing_data = read_in_file_data("nnTestData.txt")
    perceptron = Perceptron()
    while True:
        print("Please Select an Option (1/2/3/4/5)")
        print("1. Perform Neural Network Algorithm")
        print("2. Store current weights into a file")
        print("3. Load Weights")
        print("4. Run Testing Data through Network")
        print("5. Print Weights")
        print("*. Exit")
        choice = input()
        if int(choice) == 1:
            perceptron = neural_network_algorithm(training_data, perceptron)
        elif int(choice) == 2:
            weight_file = input("What is the name of the file you would like to store the weights in?")
            perceptron.store_weights(weight_file)
            del weight_file
        elif int(choice) == 3:
            print("Please Select an Option (1/2)")
            print("1. Load Weights from File")
            print("2. Load Weights Randomly")
            print("*. Exit")
            choice2 = input()
            if int(choice2) == 1:
                weight_file = input("What is the name of the file you would like to load?")
                perceptron.load_weights(weight_file)
                del weight_file
            elif int(choice2) == 2:
                perceptron = Perceptron()
            else:
                sys.exit(0)
        elif int(choice) == 4:
            neurons = run_testing_data(testing_data, perceptron)
            global CONTINENTS
            for cont in CONTINENTS:
                neurons[cont].print_neuron()
        elif int(choice) == 5:
            perceptron.print_weights()
        else:
            sys.exit(0)


def neural_network_algorithm(training_data, perceptron):
    global NUM_EPOCHS
    for i in range(NUM_EPOCHS):
        cur_dataset = copy.deepcopy(training_data)
        while len(cur_dataset) > 0:
            cur_data = cur_dataset.pop(random.randint(0, len(cur_dataset)-1))
            perceptron.update_weights(cur_data)
    return perceptron


def run_testing_data(test_data, perceptron):
    global CONTINENTS
    # True Postives: How many continents were guessed correctly as matches?
    # True Negatives: How many continents were guessed correctly as mismatches?
    # False Positives: How many continents were guessed incorrectly as matches?
    # False Negatives: How many continents were guessed incorrectly as mismatches?
    neurons = {}
    for cont in CONTINENTS:
        neurons[cont] = Neuron(cont)
    for data in test_data:
        neurons = run_data_point(data, perceptron, neurons)
    return neurons


def run_data_point(data_point, perceptron, neurons):
    global CONTINENTS
    guesses = perceptron.get_guesses(data_point)
    for cont in CONTINENTS:
        guess = guesses[cont]
        actual = int(data_point.continent == cont)
        if guess == 1 and actual == 1:
            neurons[cont].true_positives += 1
        elif guess == 1 and actual == 0:
            neurons[cont].false_positives += 1
        elif guess == 0 and actual == 1:
            neurons[cont].false_negatives += 1
        elif guess == 0 and actual == 0:
            neurons[cont].true_negatives += 1
    return neurons


if __name__ == "__main__":
    main()
