Compile & Run instructions:

	python project2.py <training file> <number of chromosomes> <number of generations> <elitist or tourament> <selection percentage> <uniform or kpoint> <mutation percentage>
		training file: 		String  (contains .txt extension)
		number of chromosomes:  integer (positive)
		number of generations:  integer (positive)
		elitist or tournament:  String  ("elitist" or "tournament")
		selection percentage:   float   (between 0 and 1)
		uniform or kpoint:      String  ("uniform" or "kpoint")
		mutation percentage:    float   (between 0 and 1)

Example command:

	python project2.py debug.txt 5 5 tournament 0.5 uniform 0.2
		- using debug.txt as training data
		- 5 chromosomes per generation
		- 5 generations
		- tournament selection
		- 50% of population selected
		- kpoint crossover
		- 20% mutation rate
		

Required Python Libraries:
	sys
		Standard Python Library
	time
		Standard Python Library
	copy
		Standard Python Library?
	numpy
		pip3 install numpy
		pip install numpy
	