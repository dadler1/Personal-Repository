import sys
import time
import numpy as np
import copy


class Chromosome:
    def __init__(self, lower1, upper1, lower2, upper2, recommendation):
        self.lower1 = lower1
        self.upper1 = upper1
        self.lower2 = lower2
        self.upper2 = upper2
        self.recommendation = recommendation
        self.fitness = 0

    def set_fitness(self, input_data):
        # Use input file to calculate fitness of chromosome
        self.fitness = 0
        fitnesses = []
        for line in input_data:
            match = int(self.lower1 <= line[0] <= self.upper1 and self.lower2 <= line[1] <= self.upper2)  # equals 0 or 1 depending on whether there is a match or not
            profit = int(2 * (int((2*self.recommendation - 1)) * line[2] > 0) - 1)  # equals -1 or 1 depending on whether a profit is made
            cur_fitness = (match * profit * round(abs(line[2]), 2))  # if not a match, this equals 0, if profit is made, it is positive, if profit is lost, it is negative.
            self.fitness += cur_fitness
            fitnesses.append(cur_fitness)
        self.fitness = round(sum(fitnesses),2)

    def __str__(self):
        return str(self.lower1) + "\t" + str(self.upper1) + "\t" + str(self.lower2) + "\t" + \
               str(self.upper2) + "\t" + str(self.recommendation) + "\tfitness: " + str(self.fitness) + "\n"


""" parses command line arguments into their respective variables"""


def parse_arguments():
    if len(sys.argv) != 8:
        raise ValueError('Insufficient Arguments. Please compile as such: python project2.py <training file>'
                         ' <number of chromosomes> <number of generations> <elitist or tournament>'
                         ' <selection percentage> <uniform or kpoint> <mutation rate>')
    return sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4], float(sys.argv[5]), sys.argv[6], float(sys.argv[7])


""" Function responsible for obtaining the random values required for each chromosome"""


def get_normal_random():
    return round(np.random.normal(loc=0.0, scale=1.15, size=None), 2)


""" returns a list of chromosomes based on the training file and the number of chromosomes allowed. """


def generate_chromosomes(num_chromosomes):
    chromosomes = []
    np.random.seed(int(time.time()))  # Seeding the Random Number Generator
    for i in range(num_chromosomes):

        """ Dictate values within each chromosome"""
        random_values_1 = [get_normal_random(), get_normal_random()]
        random_values_1.sort()
        random_values_2 = [get_normal_random(), get_normal_random()]
        random_values_2.sort()

        """ Provide each chromosome with those values"""
        cur_chromosome = Chromosome(lower1=random_values_1[0], upper1=random_values_1[1], lower2=random_values_2[0],
                                    upper2=random_values_2[1], recommendation=np.random.randint(0, 2))

        """ Add this chromosome to the list of chromosomes"""
        chromosomes.append(cur_chromosome)

    return chromosomes


""" returns an array of tuples containing training data based on the training data file name """


def get_training_data(training_file):
    training_data = []
    file = open(training_file)
    raw_data = file.readlines()
    for line in raw_data:
        clean_line = line.split("\n")[0].split("\t")
        for i in range(len(clean_line)):
            clean_line[i] = float(clean_line[i])
        training_data.append(clean_line)
    return training_data


""" helper function that returns the children of two Chromosomes """


def reproduce(parents, uniform_or_kpoint):
    lowercase = uniform_or_kpoint.lower()
    if lowercase != "uniform" and lowercase != "kpoint":

        raise ValueError('Insufficient Arguments. Please compile as such: python project2.py <training file>'
                         ' <number of chromosomes> <number of generations> <elitist or tournament>'
                         ' <selection percentage> <uniform or kpoint> <mutation rate>')
        sys.exit()
    if uniform_or_kpoint.lower() == "uniform":
        child = Chromosome(parents[np.random.randint(0, 2)].lower1, parents[np.random.randint(0, 2)].upper1,
                                   parents[np.random.randint(0, 2)].lower2, parents[np.random.randint(0, 2)].upper2,
                                   parents[np.random.randint(0, 2)].recommendation)

    else:
        child = Chromosome(parents[0].lower1, parents[0].upper1,
                                   parents[1].lower2, parents[1].upper2,
                                   parents[1].recommendation)

    return child


""" takes in a list of chromosomes and returns a mutated version of them based on the mutation rate"""


def mutate(chromosomes, mutation_rate):
    for i in range(len(chromosomes)):
        """ boolean values that dictate whether or not gene should be mutated"""
        lower1mutate = (np.random.uniform(0, 1) <= mutation_rate)
        upper1mutate = (np.random.uniform(0, 1) <= mutation_rate)
        lower2mutate = (np.random.uniform(0, 1) <= mutation_rate)
        upper2mutate = (np.random.uniform(0, 1) <= mutation_rate)
        recmutate = (np.random.uniform(0, 1) <= mutation_rate)
        if lower1mutate:
            chromosomes[i].lower1 = int(lower1mutate) * get_normal_random() + \
                                    int(not lower1mutate) * chromosomes[i].lower1
            while chromosomes[i].lower1 >= chromosomes[i].upper1:
                chromosomes[i].lower1 = int(lower1mutate) * get_normal_random() + \
                                        int(not lower1mutate) * chromosomes[i].lower1
        if upper1mutate:
            chromosomes[i].upper1 = int(upper1mutate) * get_normal_random() + \
                                    int(not upper1mutate) * chromosomes[i].upper1
            while chromosomes[i].upper1 <= chromosomes[i].lower1:
                chromosomes[i].upper1 = int(upper1mutate) * get_normal_random() + \
                                        int(not upper1mutate) * chromosomes[i].upper1
        if lower2mutate:
            chromosomes[i].lower1 = int(lower2mutate) * get_normal_random() + \
                                    int(not lower2mutate) * chromosomes[i].lower2
            while chromosomes[i].lower2 >= chromosomes[i].upper2:
                chromosomes[i].lower2 = int(lower2mutate) * get_normal_random() + \
                                        int(not lower2mutate) * chromosomes[i].lower2
        if upper2mutate:
            chromosomes[i].upper2 = int(upper2mutate) * get_normal_random() + \
                                    int(not upper2mutate) * chromosomes[i].upper2
            while chromosomes[i].upper2 <= chromosomes[i].lower2:
                chromosomes[i].upper2 = int(upper2mutate) * get_normal_random() + \
                                        int(not upper2mutate) * chromosomes[i].upper2

        chromosomes[i].recommendation = int(recmutate) * np.random.randint(0, 2) + \
                                        int(not recmutate) * chromosomes[i].recommendation
    return chromosomes


""" assigns fitness values for each chromosome in list """


def assign_fitnesses(chromosomes, input_data):
    for chromosome in chromosomes:
        chromosome.set_fitness(input_data)
    return chromosomes


""" function used for sorting chromosomes by fitness"""


def fit_func(c):
    return c.fitness


""" selects fittest chromosomes from list """


def selection(chromosomes, elitist_or_tournament, x):
    lowercase = elitist_or_tournament.lower()
    fittest_chromosomes = []
    if lowercase != "elitist" and lowercase != "tournament":
        raise ValueError('Insufficient Arguments. Please compile as such: python project2.py <training file>'
                         ' <number of chromosomes> <number of generations> <elitist or tournament>'
                         ' <selection percentage> <uniform or kpoint> <mutation rate>')
        sys.exit()
    if lowercase == "elitist":
        chromosomes.sort(reverse=True, key=fit_func)
        fittest_chromosomes = chromosomes[0:x]

    else:
        while(len(fittest_chromosomes) < x):
            chromosome1 = chromosomes[np.random.randint(0, len(chromosomes))]
            chromosome2 = chromosomes[np.random.randint(0, len(chromosomes))]
            fittest_chromosomes.append(max(chromosome1, chromosome2, key=fit_func))
    print("\n\nFittest Chromosomes: \n\n")
    print_chromosomes(fittest_chromosomes)
    print("\n")
    return fittest_chromosomes


""" prints the values of each chromosome in the list"""


def print_chromosomes(chromosomes):
    fitnesses = []
    for chromosome in chromosomes:
        fitnesses.append(chromosome.fitness)
        print(chromosome)
    print("\nmax: " + str(max(fitnesses)))
    print("min: " + str(min(fitnesses)))
    print("mean:" + str(round(sum(fitnesses)/len(fitnesses), 2)))


""" creates the new generation based on the old one"""


def new_generation(partial_chromosomes, num_chromosomes, uniform_or_kpoint):
    chromosomes = copy.deepcopy(partial_chromosomes)
    while len(chromosomes) < num_chromosomes:
        parents = [partial_chromosomes[np.random.randint(0, len(partial_chromosomes))], partial_chromosomes[np.random.randint(0, len(partial_chromosomes))]]
        child = reproduce(parents, uniform_or_kpoint)
        chromosomes.append(child)
    return chromosomes


""" main function"""


def main():
    training_file, num_chromosomes, num_generations, elitist_or_tournament, selection_rate, uniform_or_kpoint, mutation_rate = parse_arguments()
    training_data = get_training_data(training_file)
    chromosomes = generate_chromosomes(num_chromosomes)
    num_descendants = int(num_chromosomes*selection_rate)
    chromosomes = assign_fitnesses(chromosomes, training_data)
    print_chromosomes(chromosomes)

    for i in range(num_generations):
        print("Generation " + str(i + 1) + ": ")
        chromosomes = selection(chromosomes, elitist_or_tournament, num_descendants)   # survival of the fittest
        chromosomes = new_generation(chromosomes, num_chromosomes, uniform_or_kpoint)  # reproduction
        chromosomes = mutate(chromosomes, mutation_rate)                               # mutation
        chromosomes = assign_fitnesses(chromosomes, training_data)                     # determine fitness
        print_chromosomes(chromosomes)


if __name__ == '__main__':
    main()

