import java.util.*;


public class Level {	
	private Board board;
	private Space winningSpace;
	private int numMoves;
	
	//TODO fill out this class with a Level constructor
	//all the other methods necessary and any other instance variables needed
	public Level(int nRows, int nCols) {
		setupLevel(nRows,nCols);
	}
	
	public int getNumMoves() {
		return numMoves;
	}
	
	public void incramentMoves() {
		numMoves++;
	}
	
	public void setupLevel(int maxRows, int maxCols) {
		board = new Board(maxRows,maxCols);
		winningSpace = new Space(2,5);
		numMoves = 0;
		board.addVehicle(VehicleType.MYCAR, 2, 0, 2, false);
		board.addVehicle(VehicleType.TRUCK, 2, 2, 3, true);
		board.addVehicle(VehicleType.TRUCK, 2, 3, 3, true);
		board.addVehicle(VehicleType.AUTO, 0, 3, 2, true);
		board.addVehicle(VehicleType.AUTO, 1, 4, 2, true);
		board.addVehicle(VehicleType.AUTO, 5, 2, 2, false);
	}
	
	public Vehicle getVehicle(Space space) {
		return board.getVehicle(space);
	}
	
	/**
	 * @return the number of columns on the board
	 */
	public int getColumns() {
		return this.board.getNumCols();
	}
	
	public int getRows() {
		return this.board.getNumRows();
	}
	
	public Space getGoalSpace() {
		return winningSpace;
	}
	
	public boolean moveNumSpaces(Space space, int numSpaces) {
		boolean b = board.moveNumSpaces(space, numSpaces);
		System.out.println(b);
		return b;
	}
	
	public boolean passedLevel() {
		Vehicle vehicle = board.getVehicle(winningSpace);
		if(vehicle == null)
			return false;
		if(vehicle.getVehicleType()==VehicleType.MYCAR)
			return true;
		return false;
	}
	
	//Methods already defined for you
	
	
	
	/**
	 * This method will add the row information
	 * needed to the board and is used by the toString method
	 * 
	 * @param origBoard the original board without the header information
	 * @return the board with the header information
	 */
	private String addRowHeader(String origBoard) {
		String result = "";
		String[] elems = origBoard.split("\n");
		for(int i = 0; i < elems.length; i++) {
			result += (char)('A' + i) + "|" + elems[i] + "\n"; 
		}
		return result;
	}
	
	/**
	 * This one is responsible for making the row of column numbers at the top and is used by the toString method
	 * 
	 * @param cols the number of columns in the board
	 * @return if the # of columns is five then it would return "12345\n-----\n"
	 */
	private String generateColHeader(int cols) {
		String result = "  ";
		for(int i = 1; i <= cols; i++) {
			result+=i;
		}
		result+="\n  ";
		for(int i = 0; i < cols; i++) {
			result+="-";
		}
		result+="\n";
		return result;
	}
	
	/**
	 * generates the string representation of the level, including the row and column headers to make it look like
	 * a table
	 * 
	 * @return the string representation
	 */
	
	public String toString() {
		String result = generateColHeader(getColumns());
		result+=addRowHeader(board.toString());
		return result;
	}
}
