import acm.program.*;
import acm.graphics.*;
import acm.util.*;
import java.awt.event.*;
import java.awt.*;

public class GraphicsGame extends GraphicsProgram {
	/**
	 * Here are all of the constants
	 */
	public static final int PROGRAM_WIDTH = 500;
	public static final int PROGRAM_HEIGHT = 500;
	public static final String lABEL_FONT = "Arial-Bold-22";
	public static final String EXIT_SIGN = "EXIT";
	public static final String IMG_FILENAME_PATH = "images/";
	public static final String IMG_EXTENSION = ".png";
	public static final String VERTICAL_IMG_FILENAME = "_vert";
	public static final double CAR_SIZE_OFFSET = 1.6;
	// TODO declare your instance variables here
	private Level level;
	private double lastY;
	private double lastX;
	private double initialX;
	private double initialY;
	private double xReleased;
	private double yReleased;
	private GObject toDrag;
	private Vehicle currentVehicle;
	private GLabel movesLabel;

	public void init() {
		setSize(PROGRAM_WIDTH, PROGRAM_HEIGHT);
	}
	
	public void run() {
		level = new Level(6,6);
		addMouseListeners();
		drawLevel();
		drawMovesLabel();
		
		
		
		//String s = null;
		//s.charAt(0);
	}

	@Override
	public void mousePressed(MouseEvent e) {
		lastX = e.getX();
		lastY = e.getY();
		initialX = e.getX();
		initialY = e.getY();
		currentVehicle = getVehicleFromXY(e.getX(),e.getY());
		
		GObject accessElement = getElementAt(e.getX(),e.getY());
		if(accessElement != null) {
			if(accessElement.getClass().getSimpleName().equals("GImage")) {
				toDrag = getElementAt(e.getX(), e.getY());
				remove(toDrag);
				add(toDrag);
				
			}
			System.out.println(accessElement.getClass().getSimpleName());
		}
		
		System.out.println(convertXYToSpace(e.getX(),e.getY()));
		System.out.println(getVehicleFromXY(e.getX(),e.getY()));
	}
	
	@Override
	public void mouseDragged(MouseEvent e) {
		double changeInX = e.getX()-lastX;
		double changeInY = e.getY()-lastY;
		if(toDrag!=null) {
			if(currentVehicle.isVertical()) {
				toDrag.move(0, changeInY);
				
			}else {
				toDrag.move(changeInX, 0);
			}
			lastX = e.getX();
			lastY = e.getY();
		}
		System.out.println(convertXYToSpace(e.getX(),e.getY()));
	}
	
	@Override
	public void mouseReleased(MouseEvent e) {
		xReleased = e.getX();
		yReleased = e.getY();
		Space s = null;
		if(level.moveNumSpaces(currentVehicle.getStartSpace(),calculateSpacesMoved())) {
			s = convertXYToSpace(toDrag.getX(),toDrag.getY());
			if(calculateSpacesMoved()>0) {
				level.incramentMoves();
				movesLabel.setLabel(""+level.getNumMoves());
			}
			if(level.passedLevel()){
				removeAll();
				GLabel victoryLabel = new GLabel("Congratulations, you won in " + level.getNumMoves() + " moves!");
				victoryLabel.setFont(lABEL_FONT);
				victoryLabel.setColor(Color.RED);
				victoryLabel.setLocation(PROGRAM_WIDTH/2 - victoryLabel.getBounds().getWidth()/2,PROGRAM_HEIGHT/2);
				add(victoryLabel);
			}
		}
		else
			s = currentVehicle.getStartSpace();	
		toDrag.setLocation(s.getCol()*spaceWidth(),s.getRow()*spaceHeight());
		toDrag = null;
	}
	
	private void drawMovesLabel() {
		movesLabel = new GLabel("0");
		movesLabel.setLocation(5,25);
		movesLabel.setFont(lABEL_FONT);
		add(movesLabel);
	}
	private void drawLevel() {
		if(level!=null) {
			drawGridLines();
			drawWinningTile();
			drawCars();
		}
	}

	/**
	 * This should draw the label EXIT and add it to the space that represents
	 * the winning tile.
	 */
	private void drawWinningTile() {
		GLabel exitLabel = new GLabel(EXIT_SIGN,level.getGoalSpace().getCol()*spaceWidth()+spaceWidth()/6,(level.getGoalSpace().getRow()*spaceHeight())+(5*spaceHeight()/8));
		exitLabel.setColor(Color.BLUE);
		exitLabel.setFont(lABEL_FONT);
		add(exitLabel);
	}

	/**
	 * draw the lines of the grid. Test this out and make sure you have it
	 * working first. Should draw the number of grids based on the number of
	 * rows and column in Level
	 */
	private void drawGridLines() {
		GLine newLine;
		for(int i = 0; i <= PROGRAM_WIDTH; i+= (PROGRAM_WIDTH/level.getColumns())) {
			newLine = new GLine((double)i, 0, (double)i, PROGRAM_HEIGHT);
			add(newLine);
		}
		for(int i = 0; i <= PROGRAM_HEIGHT; i+= (PROGRAM_HEIGHT/level.getRows())) {
			newLine = new GLine(0,(double)i,PROGRAM_WIDTH,(double)i);
			add(newLine);
		}
	}

	/**
	 * Maybe given a list of all the cars, you can go through them and call
	 * drawCar on each?
	 */
	private void drawCars() {
		drawCar(level.getVehicle(new Space(2,0)));
		drawCar(level.getVehicle(new Space(2,2)));
		drawCar(level.getVehicle(new Space(2,3)));
		drawCar(level.getVehicle(new Space(0,3)));
		drawCar(level.getVehicle(new Space(1,4)));
		drawCar(level.getVehicle(new Space(5,2)));
	}

	/**
	 * Given a vehicle object, which we will call v, use the information from
	 * that vehicle to then create a GImage and add it to the screen. Make sure
	 * to use the constants for the image path ("/images"), the extension ".png"
	 * and the additional suffix to the filename if the object is vertical when
	 * creating your GImage. Also make sure to set the images size according to
	 * the size of your spaces
	 * 
	 * @param v
	 *            the Vehicle object to be drawn
	 */
	private void drawCar(Vehicle v) {
		GImage carImage = v.getImageFile(v.getStartCol()*spaceWidth(), v.getStartRow()*spaceHeight());
		carImage.setSize(carImage.getWidth()*CAR_SIZE_OFFSET,carImage.getHeight()*CAR_SIZE_OFFSET);
		add(carImage);
	}

	// TODO implement the mouse listeners here

	/**
	 * Given a xy coordinates, return the Vehicle that is currently at those x
	 * and y coordinates, returning null if no Vehicle currently sits at those
	 * coordinates.
	 * 
	 * @param x
	 *            the x coordinate in pixels
	 * @param y
	 *            the y coordinate in pixels
	 * @return the Vehicle object that currently sits at that xy location
	 */
	private Vehicle getVehicleFromXY(double x, double y) {
		return level.getVehicle(convertXYToSpace(x,y));
	}

	/**
	 * This is a useful helper function to help you calculate the number of
	 * spaces that a vehicle moved while dragging so that you can then send that
	 * information over as numSpacesMoved to that particular Vehicle object.
	 * 
	 * @return the number of spaces that were moved
	 */
	private int calculateSpacesMoved() {
		int deltaXSpaces = (int) Math.floor((xReleased-initialX)/spaceWidth());
		int deltaYSpaces = (int) Math.floor((yReleased-initialY)/spaceHeight());
		if(currentVehicle.isVertical()) {
			System.out.println(deltaYSpaces);
			return deltaYSpaces;
		}
		System.out.println(deltaXSpaces);
		return deltaXSpaces;
		
	}

	/**
	 * Another helper function/method meant to return the space given an x and y
	 * coordinate system. Use this to help you write getVehicleFromXY
	 * 
	 * @param x
	 *            x-coordinate (in pixels)
	 * @param y
	 *            y-coordinate (in pixels)
	 * @return the Space associated with that x and y
	 */
	private Space convertXYToSpace(double x, double y) {
		return new Space((int)Math.floor(y/(spaceHeight())),(int)Math.floor(x/(spaceWidth())));
	}

	/**
	 * 
	 * @return the width (in pixels) of a single space in the grid
	 */
	private double spaceWidth() {
		return (double)PROGRAM_WIDTH/(double)level.getColumns();
	}

	/**
	 * 
	 * @return the height in pixels of a single space in the grid
	 */
	private double spaceHeight() {
		return (double)PROGRAM_HEIGHT/(double)level.getRows();
	}
	
	
}
