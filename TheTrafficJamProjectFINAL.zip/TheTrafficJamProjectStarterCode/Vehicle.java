import acm.graphics.*;


public class Vehicle {
	private VehicleType vtype;
	private Space start;
	private int length;
	private boolean vertical;
	
	private Space[] getSpacesBetween(int r1, int c1, int r2, int c2) {
		
		Space[] interval;
		Space startSpace = new Space(r1,c1);
		Space endSpace = new Space(r2,c2);
		if(startSpace.getRow() == endSpace.getRow()) {
			interval = new Space[Math.abs(startSpace.getCol()-endSpace.getCol())];	// Defines the length of interval
			for(int i = 0; i < interval.length; i++) {						// sets interval to all spaces between r1c1 and r2c2
				interval[i]= new Space(startSpace.getRow(), startSpace.getCol()+i);
			}	
			return interval;
		} else if(startSpace.getCol() == endSpace.getCol()) {
			interval = new Space[Math.abs(startSpace.getRow()-endSpace.getRow())];	// Defines the length of interval
			for(int i = 0; i < interval.length; i++) {						// sets interval to all spaces between r1c1 and r2c2
				interval[i]= new Space(startSpace.getRow()+i, startSpace.getCol());
			}
			return interval;
		}
		System.out.println("returned null");
		return null;
		
	}
	/**
	 * Constuctor for Vehicle class.
	 * 
	 * @param the type, a starting row and column, a length, and whether the Vehicle is vertical 
	 *            
	 * @return N/A
	 */
	public Vehicle(VehicleType vtype, int startingRow, int startingCol, int length, boolean vertical) {
		this.vtype = vtype;
		this.start = new Space(startingRow,startingCol);
		this.length = length;
		this.vertical = vertical;
	}
	
	/**
	 * ToString method for the Vehicle class.
	 * 
	 * @param N/A
	 *            
	 * @return A string representation of the most relevant data in the Vehicle class.
	 */
	public String toString() {
		String vehicleSpaces = "";
		Space[] occupied = spacesOccupied();
		for(int i = 0; i < occupied.length-1;i++)		//compiles a String representation of all spaces
			vehicleSpaces+=occupied[i]+", ";			//being occupied by vehicle
		vehicleSpaces+=occupied[occupied.length-1]; 
		return "Vehicle type: " + vtype + "Spaces Occupied: " + vehicleSpaces + "Starting Position: " + start;
	}

	/**
	 * @return the type associated with this particular vehicle
	 */
	public VehicleType getVehicleType() {
		return vtype;
	}
	public Space getStartSpace() {
		return start;
	}
	
	/**
	 * @return a boolean representing whether the vehicle is vertical or not.
	 */
	public boolean isVertical() {
		return vertical;
	}
	
	public int getLength() {
		return length;
	}
	
	/**
	 * @param startRow
	 * 				The starting row of this vehicle
	 */
	public void setStartRow(int newRow) {
		this.start.setRow(newRow);
	}
	
	public int getStartRow() {
		return this.start.getRow();
	}
	/**
	 * @param startCol
	 * 				The starting column of this vehicle
	 */
	public void setStartCol(int newCol) {
		this.start.setCol(newCol);
	}
	public int getStartCol() {
		return this.start.getCol();
	}
	/**
	 * Changes the position of the Vehicle by changing start to a new space.
	 * 
	 * @param int nSpaces
	 * 				The amount of spaces you would like to move
	 */
	public void move(int nSpaces) {
		start = ifIWereToMove(nSpaces);
	}
	/**
	 * Calculates new start Space of this vehicle after moving nSpaces spaces
	 * 
	 * @param nSpaces
	 * 				The amount of spaces to move
	 * @return
	 * 				the new start Space after moving nSpaces spaces.
	 */
	public Space ifIWereToMove(int nSpaces) {
		if(vertical) {
			return new Space(start.getRow()+nSpaces,start.getCol());
		}
		return new Space(start.getRow(),start.getCol()+nSpaces);
	}
	
	/**
	 * Provides an array of Spaces that indicate where a particular Vehicle
	 * would be located, based on its current starting space
	 * 
	 * @return the array of Spaces occupied by that particular Vehicles
	 */
	public Space[] spacesOccupied() {
		if(vertical) {
			
			return getSpacesBetween(start.getRow(),start.getCol(), start.getRow()+length,start.getCol());
		}
		
		return getSpacesBetween(start.getRow(),start.getCol(), start.getRow(),start.getCol()+length);
	}

	/**
	 * Calculates an array of the spaces that would be travelled if a vehicle
	 * were to move numSpaces
	 * 
	 * @param numSpaces
	 *            The number of spaces to move (can be negative or positive)
	 * @return The array of Spaces that would need to be checked for Vehicles
	 */
	public Space[] spacesOccupiedOnTrail(int nSpaces) {
		if(vertical) {
			if(nSpaces>0) {
				return getSpacesBetween(start.getRow()+length,start.getCol(),start.getRow()+(length)+nSpaces, start.getCol()); //r1= space just after path, c1 = starting column, r2 = space at end of path, c2 = starting column
			}
			return getSpacesBetween(start.getRow()+nSpaces,start.getCol(),start.getRow(),start.getCol());
		} 
		if(nSpaces>0) {
			return getSpacesBetween(start.getRow(),start.getCol()+length,start.getRow(), start.getCol()+(length)+nSpaces);
		}
		return getSpacesBetween(start.getRow(),start.getCol()+nSpaces,start.getRow(),start.getCol());
	}
	
	public static void printSpaces(Space[] spaces) {
		for(int i = 0; i < spaces.length; i++)
			System.out.print(spaces[i] + " ");
		System.out.println();
		
	}
	public static void main(String[] args) {
		//this snippet would go inside of a public static void main in Vehicle.java
		//Assume Vehicle constructor is type, startRow, startCol, length, isVertical
		
		
		Vehicle someTruck = new Vehicle(VehicleType.TRUCK, 1, 1, 3, false);
		
		
		
		
		Vehicle someAuto = new Vehicle(VehicleType.AUTO, 2, 2, 2, false);
		System.out.println("This next test is for spacesOccupied: ");
		System.out.println("vert truck at r1c1 should give you r1c1; r2c1; r3c1 as the spaces occupied:does it?");
		printSpaces(someTruck.spacesOccupied());
		System.out.println("horiz auto at r2c2 should give you r2c2; r2c3 as the spaces occupied:does it?");
		printSpaces(someAuto.spacesOccupied());
		System.out.println("if we were to move horiz auto -2 it should give you at least r2c0; r2c1; it may also add r2c2; r2c3 to its answer:does it?");
		printSpaces(someAuto.spacesOccupiedOnTrail(-2));
		System.out.println("After being called, ifIWereToMove should return the cars position if it were to move 3 spaces (r2c5), but it's position should remain (r2c2).");
		System.out.println("Hypothetical Position: " +someAuto.ifIWereToMove(3));
		System.out.println("Actual Position: " + someAuto.start);
		System.out.println("After moving someTruck 4 spaces, someTruck's new start position should be r5c1");
		someTruck.move(4);
		System.out.println(someTruck.start);
		
	}
	
	public GImage getImageFile(double x, double y) {
		String addOn = new String();
	    String vehicle = vtype.toString();
		if(vertical) {
			addOn = "_vert";
		}
		String filePath = "images/"+vehicle+addOn+".png";
		return new GImage(filePath,x,y);
	}
}

	
